# coding: utf-8
# Импортирует поддержку UTF-8.
from __future__ import unicode_literals

# Импортируем модули для работы с JSON и логами.
import json
import logging

# Импортируем подмодули Flask для запуска веб-сервиса.
from flask import Flask, request
app = Flask(__name__)


logging.basicConfig(level=logging.DEBUG)

# Хранилище данных о сессиях.
sessionStorage = {}

# Задаем параметры приложения Flask.
@app.route("/", methods=['POST'])

def main():
# Функция получает тело запроса и возвращает ответ.
    logging.info('Request: %r', request.json)

    response = {
        "version": request.json['version'],
        "session": request.json['session'],
        "response": {
            "end_session": False
        }
    }

    handle_dialog(request.json, response)

    logging.info('Response: %r', response)

    return json.dumps(
        response,
        ensure_ascii=False,
        indent=2
    )

def handle_dialog(req, res):
    user_id = req['session']['user_id']

    if req['session']['new']:
        res['response']['text'] = "Привет! Вы называете социальный навык или ситуацию, с которой вам нужно справиться, а я помогаю проработать вам этот навык. Начнем?"
        res['response']['tts'] = "Привет! Вы называете социальный навык или ситуацию, с которой вам нужно справиться, а я помогаю проработать вам этот навык. Начнем?"
        sessionStorage[user_id] = {}
        return

    user_message = req['request']['original_utterance'].lower()

    if "что ты умеешь" in user_message:
        res['response']['text'] = (
            "Я помогаю детям и подросткам с РАС (и не только) справиться с социальными ситуациями, с которыми у них возникают сложности, и обрести навыки, помогающие им в повседневной жизни. Я рассказываю социальные истории и отыгрываю воображаемые социальные ситуации за других людей или персонажей, чтобы тем самым помочь вам справиться с тревожностью или обрести новые навыки"
            "Начнем?"
        )
        res['response']['tts'] = (
            "Я помогаю детям и подросткам с РАС (и не только) справиться с социальными ситуациями, с которыми у них возникают сложности, и обрести навыки, помогающие им в повседневной жизни. Я рассказываю социальные истории и отыгрываю воображаемые социальные ситуации за других людей или персонажей, чтобы тем самым помочь вам справиться с тревожностью или обрести новые навыки"
            "Начнем?"
        )
    else:
        res['response']['text'] = "Я не совсем поняла. Можешь уточнить свой вопрос?"
        res['response']['tts'] = "Я не совсем поняла. Можешь уточнить свой вопрос?"

